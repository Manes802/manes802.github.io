#ifndef FONCTIONS_BASIQUES
    #define FONCTIONS_BASIQUES

    //Les directives
    #include <stdio.h>
    #include <stdlib.h>
    #include <ctype.h>
    #include <string.h>
    //Mes prototypes
    #include "fonctions_basiques.h"

    //les prototypes
    void message_bienvenu();
    char read_Char();
    void decision(char *pdecision);
    int lire(char *texte, int nombre_caractere);

#endif
