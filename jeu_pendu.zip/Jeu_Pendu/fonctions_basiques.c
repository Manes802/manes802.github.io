#include "fonctions_basiques.h"
//Les defines
#define NBR_CARACTERE 200

//LES FONCTIONS BASIQUES DU PROGRAMME : message de bienvenu, d�cision de rejouer ou non, read_Char, message d'aurevoir

//MESSAGE DE BIENVENU
/*
    Cette fonction affiche un message de bienvenu dans le jeu du pendu et propose au joueur de lire la r�gle du jeu.
*/
void message_bienvenu()
{
    //presentation
    printf("\t\t\t\t\t\t\t\tMANES STUDIO presente\n");
    printf("________________________________________________________________\n\n");
    printf("\t\t\t   LE PENDU\n");
    printf("________________________________________________________________\n\n");

    //Proposer la lecture de la r�gle du jeu.
    char lecture_regle_du_jeu = 'I';

    printf("Lire la r%cgle du jeu (recommand%ce).\nTaper i pour la lire ou autre touche pour passer directement au jeu : ", 138, 130);
    lecture_regle_du_jeu = read_Char();

    //Si le joueur accepte de lire, on lui ouvre le fichier texte. sinon la fonction prend fin
    if(lecture_regle_du_jeu == 'I')
    {
        FILE *regle_du_jeu = NULL;

        regle_du_jeu = fopen("Aide.txt", "r");
        if(regle_du_jeu != NULL)
        {
            char phrase[NBR_CARACTERE] = "";

            while(fgets(phrase, NBR_CARACTERE, regle_du_jeu) != NULL)
            {
                printf("%s", phrase);
            }

            fclose(regle_du_jeu);
        }
        else
        {
            printf("Erreur d'ouverture du fichier Aide.txt !\n\n");
        }
    }
    else
        printf("\n");
}//FIN DE LA FONCTION message_bienvenu

//LECTURE DE CARACTERE;
/*
    Cette fonction est l� pour �viter le prob�me de caract�re non d�sir�s.
    La fonction doit alors �liminer tous les caract�res apr�s le premier.
*/
char read_Char()
{
    char caractere = '0';

    caractere = getchar();
    caractere = toupper(caractere);

    while(getchar() != '\n');//on lit (�limine) les autres caract�re jusqu'au \n representant la touche entr�.

    return caractere;
}

//DECISION : rejouer ou non ?
void decision(char *pdecision)
{

    printf("Tapez R pour rejouer ou Q pour quitter : ");
    *pdecision = read_Char();

    while(*pdecision != 'R' && *pdecision != 'Q')
    {
        printf("Erreur ! %c n'est pas pris en charge.\nTapez R pour rejouer ou Q pour quitter : ", *pdecision);
        *pdecision = read_Char();
    }
}

/*
	Fonction de lecture de texte saisi pointeurr l'utilisateur.
	Cette fonction prend en param�tre la chaine � lire et le nombre de caract�re � lire. Une fois recup�rer les caract�re tap�s au clavier,
	On recherche le carat�re de retour � la ligne '\n' dans la chaine. Si on trouve, on le remplace par la carct�re de fin de la chaine.
*/
int lire(char *texte, int nombre_caractere)
{
	char *pointeur = NULL;

	if( fgets(texte, nombre_caractere, stdin) != NULL )
	{
		pointeur = strchr(texte, '\n');

		if(pointeur != NULL)
		{
			*pointeur = '\0';
		}
		else
		{
			//Vider le buffer
			char c = '0';
			while(c != '\n' && c != EOF)
			{
				c = getchar();
			}
		}
		return 1;
	}
	else
	{
		printf("Probleme dans la fonction de lecture d'entree standard.\n");

		return 0;
	}
}
