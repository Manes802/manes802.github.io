#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "jeu.h"
//Mes prototypes
#include "fonctions_basiques.h"
#include "Mode.h"

/*
                                ##### NOTE #####
                                ----------------

    J'AI ESSAI DE COMPLIQUER L'EXERCICE JUSTE POUR M'EXERCECER. CE POURQUOI, VOUS TROUVERIEZ CERTAINS FONCTIONS QUI NE SONT
    PAS VRAIMENT UTILES.
    SI DU MOINS VOUS TROUVEZ CERTAINS DE MES ALGORITHMES BEAUCOUP TROP LONG, VEUILLEZ ME LE SIGNALER AVEC UNE PROPOSITION.
                                                                                                              MANES802.11m
*/
int main()
{
    //LES VARIABLES DE LA FONCTION PRINCIPALE
    char rejouer = 'R',//Cette variable permet de savoir si l'utilisateur veut rejouer ou non.
         modejeu = '0';

    //Message de bienvenu et proposition de la lecture des r�gles du jeu.
    message_bienvenu();

    //C'est ici que le jeu commence.
    do
    {
        int level = 0;
        long curseur = 0;//Cette variable va permettre de recup�rer la position du cruseur.

        //CONFIGURATION DU JEU : Choix du mode et du niveau de jeu.
        level = niveau_de_jeu();
        mode(&modejeu);
        inscription(&modejeu, &curseur);/*Une fois le mode choisi, on enregistre le joueur au cas o� son pseudo n'existe pas dans le fichier
                                Contenant la liste des joueurs. Voire la fonction dans la fonction Mode.c pour mieux connaitre son fonctionnement.*/

        printf("\n");

        senario_du_jeu(&modejeu, level, &curseur);

        //Rejouer le jeu ou non ?
        decision(&rejouer);

        /*
            Si le mode B a �t� choisi, il va falloir supprimer puis rec�er le fichier texte contenant le mot secr�.
            Ceci permettra au joueur 1 de pouvoir d�finir un autre mot.
        */
        supprimer_mot_secret(&modejeu);

        printf("\n");
    }while(rejouer == 'R');//FIN DE LA GRANDE BOUCLE DU JEU

    printf("\t\t\t\t###### MERCI D'AVOIR JOUER AU PENDU ######\n");

    return 0;
}
