#include "Mode.h"
#include "fonctions_basiques.h"
#define TAILLE_MOT 30

/*
    lA FONCTION MODE :
    Elle affiche les diff�rents mode du jeu et oblige le joueur a choisir un mode valide.
    Etant donn� que la fonction prend en param�tre un pointeur,...elle modifiera directement
    la valeur de la variable modejeu de la fonction main().
*/
void mode(char *pMode)
{
    printf("\nLES MODES DU JEU :\n");
    printf("________________\n\n");
    printf("\ta- Mode solo (un joueur contre la machine)\n");
    printf("\tb- Mode duo (deux joueurs J1 Vs J2)\n\n");

    printf("Veuillez choisir un mode de jeu : ");
    *pMode = read_Char();

    while(*pMode != 'A' && *pMode != 'B')
    {
        printf("Le mode %c n'existe pas. Veuillez choisir l'un des modes propos%cs : ", *pMode, 130);
        *pMode = read_Char();
    }
    printf("\n");
}

/*
    Cette fonction va permettre d'inscrire un nouveau joueur, si le joueur n'existe pas dans le fichier contenant la liste des
    joueurs. Au cas o� le pseaudo existe d�j� la fonction demande un mot de pass, pour des raisons de s�curit�. Si le mot de
    passe n'est pas correcte on donne au joueur 3 chances pour retrouver son MP, apr�s les 3 chances �puis�es, il ou elle doit
    cr�er un autre identifiant au prochain jeu, soit quitter le jeu pour r�essayer de retrouver son MP.
*/
void inscription(char *pmode, long *cursor)
{
    //MODE A
    if(*pmode == 'A')
    {
        printf("\t\t#### VOUS JOUEZ EN MODE SOLO ####\n");

        //Cr�ation d'un fichier de donn�es du joueur
        FILE *fichierJ = NULL;

        fichierJ = fopen("DONNES JOUEURS/Solo/Joueur_unique.txt", "r+");

        if(fichierJ != NULL)
        {
            //Declaration d'une variable de type Joueur
            Joueur j = {"", "", 0};

            printf("Indentifier vous. Si votre identifiant n'existe pas, il sera directrement cr%c%c.\n\n", 130, 130);
            printf("Pseudo : ");
            lire(j.pseudo, TAILLE_PSEUDO);

            /*
                Une fois le pseudo re�u, on cherche dans le fichier pour voir si le joueur existe d�j� ou non
            */

            int pseudo_existe = 0;//Permet de savoir si le pseudo existe deja ou il faut cr�er

            char verificateur[TAILLE_PSEUDO] = "";//C'est la variable qui va recuperer temporellement, dans un premier temps le pseudo et apr�s le mot de passe lu dans le fichier (avec le caract�re \n)

            /*
                On entre dans cette boucle pour v�rifier ligne par ligne, le pseudo (s'il existe d�j� ou non).
            */
            rewind(fichierJ);//On se placera � chaque fois au d�but du fichier avant de rentrer dans la boucle

            while(fgets(verificateur, TAILLE_PSEUDO, fichierJ) != NULL)
            {
                /*
                    J'ai essay� dans un premier temps, d'�crire mon programme sans la boucle ci-dessous, mais h�las ! Dans
                    aucun cas le pseudo d�j� enregistr� et le pseudo qui viens d'�tre saisi par le joueur pour v�rification
                    ne sont les m�mes (m�me si le joueur a �t� d�j� enregistr�).

                    Si vous avez une autre approche pour resoudre le bl�me, veuillez me le faire savoir sur mon adresse mail
                    hermandjakamid@gmail.com
                */
                for(int i = 0; i < TAILLE_PSEUDO; i++)
                {
                    if(verificateur[i] == '\n')//J'�limine le retour � la ligne qui empeche � mon programme de faire une bonne comparaison
                    {
                        verificateur[i] = '\0';
                    }
                }

                if(strcmp(verificateur, j.pseudo) == 0)
                {
                    //Le pseudo existe d�j�, on demande le mot de passe
                    printf("Mot de passe : ");
                    lire(j.identifiant, TAILLE_IDENTIFIANT);

                    //VERIFICATION DE L'AUTHENTICITE DU MP
                    fgets(verificateur, TAILLE_IDENTIFIANT, fichierJ);

                    for(int i = 0; i < TAILLE_IDENTIFIANT; i++)
                    {
                        if(verificateur[i] == '\n')
                        {
                            verificateur[i] = '\0';
                        }
                    }

                    if(strcmp(verificateur, j.identifiant) == 0)
                    {
                        fprintf(fichierJ, "\n");
                        *cursor = ftell(fichierJ);
                        printf("Mot de passe correcte !\n");
                    }
                    else
                    {
                        int chance = 3;
                        while(chance != 0)
                        {
                            printf("Mot de passe incorrecte il vous reste %d chances d'essai.\n", chance);
                            printf("Mot de passe : ");
                            lire(j.identifiant, TAILLE_IDENTIFIANT);

                            //si le mot de pass est correcte
                            if(strcmp(verificateur, j.identifiant) == 0)
                            {
                                fprintf(fichierJ, "\n");
                                *cursor = ftell(fichierJ);
                                printf("Mot de passe correcte !\n");
                                chance = 1;
                            }
                            chance--;
                        }
                        if(strcmp(verificateur, j.identifiant) != 0)
                        {
                            printf("\nACCES BLOQUE. Veuillez relancer le jeu pour r%cessayer %c nouveau votre identifiant.\n", 130, 133);
                            printf("Si vous ne vous souvenez plus de votre identifiant, veuillez creer un autre lors du prochain demarrage du jeu.\n\n");

                            fclose(fichierJ);
                            exit(0);//On ferme le jeux.
                        }
                    }

                    pseudo_existe = 1;//Juste pour ne plus executer la condition qui suit (qui consiste � enregistrer le joueur)
                    fseek(fichierJ, 0, SEEK_END);//On met le curseur � la fin du fichier pour sortir de la boucle
                }
            }

            if(pseudo_existe == 0)//Si le joueur n'a pas �t� enregistr�
            {
                printf("Mot de passe : ");
                lire(j.identifiant, TAILLE_IDENTIFIANT);

                //ON ENREGISTRE LE JOUEUR
                fprintf(fichierJ, "%s\n%s\n%s\n\n", j.pseudo, j.identifiant, "");

                fseek(fichierJ, -3, SEEK_CUR);
                *cursor = ftell(fichierJ);
            }

             fclose(fichierJ);
        }
        else
            printf("Impossible d'acceder au fichier Joueur_unique.txt\n\n");
    }
    else//MODE B
    {
        printf("\t\t#### VOUS JOUEZ EN MODE DUO SIMPLEX\n\tJ1 doit d%cfinir le mot secret et J2 doit le retrouver.\n\n", 130);

        //Cr�ation d'un fichier de donn�es du joueur
        FILE *fichierJ1 = NULL;

        fichierJ1 = fopen("DONNES JOUEURS/Duo/Joueurs1.txt", "r+");

        if(fichierJ1 != NULL)
        {
            char verificateur[TAILLE_MOT] = "";

            if(fgets(verificateur, TAILLE_MOT, fichierJ1) != NULL)
            {
                printf("UN MOT SECRET A DEJA ETE DEFINI PAR J1. ESSAIEZ DE LE RETROUVER J2.\n");
            }
            else
            {
                char mot_Secret[TAILLE_MOT] = "";

                printf("J1 VEUILLEZ DEFINIR LE MOT SECRE : ");
                lire(mot_Secret, TAILLE_MOT);

                fprintf(fichierJ1, "%s", mot_Secret);
                printf("\nLe mot a bien %ct%c enregistr%c. Pour que J2 ne puisse pas trich%c, le programme va s'autoferm%c.\n", 130, 130, 130, 130, 130);
                printf("J2 doit relancer le jeu pour pouvoir jouer (il peut le faire quand il le voudra).\n");

                fclose(fichierJ1);

                exit(0);
            }
            fclose(fichierJ1);
        }
        else
            printf("Impossible d'acceder au fichier Joueurs.txt\n\n");
    }
}//FIN DE LA FONCTION

//CETTE A POUR ROLE DE SUPPRIMMER LE FICHIER CONTENANT LE MOT SECRET.
void supprimer_mot_secret(char *point_sur_mode)
{
    if(*point_sur_mode == 'B')
    {
        remove("Joueurs1.txt");

        FILE *fichierJ1 = NULL;

        fichierJ1 = fopen("DONNES JOUEURS/Duo/Joueurs1.txt", "w");
        if(fichierJ1 != NULL)
        {
            fclose(fichierJ1);
        }
    }
}
