#ifndef MODE
    //LES DEFINE
    #define MODE
    #define TAILLE_PSEUDO 25
    #define TAILLE_IDENTIFIANT 25
    //Directive
    #include "fonctions_basiques.h"

    //STRUCTURE
    typedef struct Joueur Joueur;

    struct Joueur
    {
        char pseudo[TAILLE_PSEUDO],
             identifiant[TAILLE_IDENTIFIANT];

        int score;
    };

    //PROTOTYPES
    void mode(char *pMode);
    void inscription(char *pmode, long *cursor);
    void supprimer_mot_secret(char *point_sur_mode);
#endif // MODE
