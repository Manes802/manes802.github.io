#ifndef JEU
    #define JEU

    typedef enum Niveau Niveau;

    enum Niveau
    {
        FACILE = 15, MOYEN = 10, DIFFICILE = 5
    };

    //PROTOTYPE
    void senario_du_jeu(char *mode_du_jeu, int niveau_du_jeu, long *cursor);
    void choisir_le_mot(char *mot_cache, FILE *fichier);
    void crypteur(char *mot_original, char *mot_crypte);
    void deroulement_du_jeu(char mot_secret[], char mot_code[], char *mode, int *score, long *curseur, Niveau *nbr_chance);
    int nombreAleatoir(int nombre_max);
    int niveau_de_jeu();
#endif // JEU
