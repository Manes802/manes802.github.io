#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <string.h>
#include "jeu.h"
#include "fonctions_basiques.h"

#define TAILLE_DEFAUT 30

/*
    SENARIO DU JEU DU PENDU.
    En fonction du mode choisi et du niveu de jeu on demande au joueur de retouver le mot en tapant lettre apr�s lettre pour
    reconstituer le mot s�cret.

    Si c'est le mode A, on fait un tirage al�atoir parmi les mots du dictionnaire.
    Si c'est le mode B, on lit simplement le fichier conenant le mot d�fini par J1
*/
void senario_du_jeu(char *mode_du_jeu, int niveau_du_jeu, long *cursor)
{
    int score = 0;

    //On cherche d'abord a connaitre le niveau choisi
    if(niveau_du_jeu == 1)//NIVEAU FACILE
    {
        //On cherche a connaitre le mode du jeu pour pouvoir determiner o� chercher le mot s�cret.
        if(*mode_du_jeu == 'A')
        {
            FILE *fichier_dico = NULL;

            fichier_dico = fopen("Dictionnaire.txt", "r");

            if(fichier_dico != NULL)//Le fichier a bien �t� ouvert
            {

                rewind(fichier_dico);

                char mot_secret[TAILLE_DEFAUT] = "";

                //choix al�atoir des mots du dico
                choisir_le_mot(mot_secret, fichier_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";

                crypteur(mot_secret, mot_crypte);

                Niveau difficulte = FACILE;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
        else//MODE B
        {
            FILE *fichier_mini_dico = NULL;

            fichier_mini_dico = fopen("DONNES JOUEURS/Duo/Joueurs1.txt", "r");

            if(fichier_mini_dico != NULL)//Le fichier a bien �t� ouvert
            {

                char mot_secret[TAILLE_DEFAUT] = "";

                rewind(fichier_mini_dico);

                //ON RECUPERE LE MOT SECRET
                fgets(mot_secret, TAILLE_DEFAUT, fichier_mini_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";
                int indice = 0;

                while(mot_secret[indice] != '\0')
                {
                    mot_crypte[indice] = '*';

                    indice++;
                }

                //On met les caract�res du mot en majuscule
                indice = 0;
                while(mot_secret[indice] != '\0')
                {
                    mot_secret[indice] = toupper(mot_secret[indice]);

                    indice++;
                }

                Niveau difficulte = FACILE;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
    }
    else if(niveau_du_jeu == 2)//NIVEAU MOYEN
    {
        //On cherche a connaitre le mode du jeu pour pouvoir determiner o� chercher le mot s�cret.
        if(*mode_du_jeu == 'A')
        {
            FILE *fichier_dico = NULL;

            fichier_dico = fopen("Dictionnaire.txt", "r");

            if(fichier_dico != NULL)//Le fichier a bien �t� ouvert
            {

                rewind(fichier_dico);

                char mot_secret[TAILLE_DEFAUT] = "";

                //choix al�atoir des mots du dico
                choisir_le_mot(mot_secret, fichier_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";

                crypteur(mot_secret, mot_crypte);

                Niveau difficulte = MOYEN;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
        else//MODE B NIVEAU 2
        {
            FILE *fichier_mini_dico = NULL;

            fichier_mini_dico = fopen("DONNES JOUEURS/Duo/Joueurs1.txt", "r");

            if(fichier_mini_dico != NULL)//Le fichier a bien �t� ouvert
            {

                char mot_secret[TAILLE_DEFAUT] = "";

                rewind(fichier_mini_dico);

                //ON RECUPERE LE MOT SECRET
                fgets(mot_secret, TAILLE_DEFAUT, fichier_mini_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";
                int indice = 0;

                while(mot_secret[indice] != '\0')
                {
                    mot_crypte[indice] = '*';

                    indice++;
                }

                //On met les caract�res du mot en majuscule
                indice = 0;
                while(mot_secret[indice] != '\0')
                {
                    mot_secret[indice] = toupper(mot_secret[indice]);

                    indice++;
                }

                Niveau difficulte = MOYEN;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
    }
    else//NIVEAU DIFFICILE
    {
        //On cherche a connaitre le mode du jeu pour pouvoir determiner o� chercher le mot s�cret.
        if(*mode_du_jeu == 'A')
        {
            FILE *fichier_dico = NULL;

            fichier_dico = fopen("Dictionnaire.txt", "r");

            if(fichier_dico != NULL)//Le fichier a bien �t� ouvert
            {

                rewind(fichier_dico);

                char mot_secret[TAILLE_DEFAUT] = "";

                //choix al�atoir des mots du dico
                choisir_le_mot(mot_secret, fichier_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";

                crypteur(mot_secret, mot_crypte);

                Niveau difficulte = DIFFICILE;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
        else//MODE B
        {
            FILE *fichier_mini_dico = NULL;

            fichier_mini_dico = fopen("DONNES JOUEURS/Duo/Joueurs1.txt", "r");

            if(fichier_mini_dico != NULL)//Le fichier a bien �t� ouvert
            {

                char mot_secret[TAILLE_DEFAUT] = "";
                int nombre_de_mot = 0;

                while(fgets(mot_secret, TAILLE_DEFAUT, fichier_mini_dico) != NULL)
                {
                    nombre_de_mot++;
                }

                rewind(fichier_mini_dico);

                //ON RECUPERE LE MOT SECRET
                fgets(mot_secret, TAILLE_DEFAUT, fichier_mini_dico);

                //Cryptage du mot secret
                char mot_crypte[TAILLE_DEFAUT] = "";
                int indice = 0;

                while(mot_secret[indice] != '\0')
                {
                    mot_crypte[indice] = '*';

                    indice++;
                }

                //On met les caract�res du mot en majuscule
                indice = 0;
                while(mot_secret[indice] != '\0')
                {
                    mot_secret[indice] = toupper(mot_secret[indice]);

                    indice++;
                }

                Niveau difficulte = DIFFICILE;
                // On joue tanqu'on a pas trouv� le mot et tanqu'on a de chance.
                printf("Vous debutez le jeu avec %d chances\n\n", difficulte);
                do
                {
                    deroulement_du_jeu(mot_secret, mot_crypte, mode_du_jeu, &score, cursor, &difficulte);
                }while(difficulte != 0 && strcmp(mot_secret, mot_crypte) != 0);

            }
            else
            {
                printf("Fichier dico, inaccecible !\n\n");
            }
        }
    }
}//FIN FONCTION SENARIO

/*
    cette fonction va permettre de choisir al�atoirement le mot dans le dico
*/

void choisir_le_mot(char *mot_cache, FILE *fichier)
{
    char mot_secret[TAILLE_DEFAUT] = "";
    int nombre_de_mot = 0;

    while(fgets(mot_secret, TAILLE_DEFAUT, fichier) != NULL)
    {
        nombre_de_mot++;
    }

    //Une fois le nombre de mot du dico connu, on fait un tirage aleatoir pour positionner le curseur virtuel net devant le mot
    //Puisque chaque ligne represente un mot.

    int ligne = nombreAleatoir(nombre_de_mot);

    rewind(fichier);
    /*
        ON RECUPERE LE MOT SECRET
        Mon algorithme consiste a se plac� au debut du fichier dico.txt, puis lire ligne apr�s ligne
        les mots jusqu'� la ligne d�fini par la variable ligne.
    */
    for(int i = 0; i < ligne; i++)
    {
        fgets(mot_secret, TAILLE_DEFAUT, fichier);
    }

    strcpy(mot_cache, mot_secret);

}//FIN FONCTION CHOISIR LE MOT SECRET


//FONCTION DE CRYPTAGE DU MOT
void crypteur(char *mot_original, char *mot_crypte)
{
    for(int j = 0; j < TAILLE_DEFAUT; j++)
    {
        if(mot_original[j] != '\n' && mot_original != '\0')
        {
            mot_crypte[j] = '*';
        }
        else
        {
            mot_crypte[j] = '\0';
            mot_original[j] = '\0';

            j = TAILLE_DEFAUT;
        }
    }
}

/*
    Cette fonction est le corps du jeu. Elle va permettre au joueur de jouer le jeu.
    Elle affiche dans un permier temps le caract�re masqu� du mot secret puis demande au joueur d'entr� un caract�re.
    Une fois le caract�re entr�, elle juge s'il est correcte ou pas... A la fin la fonction affiche le r�sultat final.
*/
void deroulement_du_jeu(char mot_secret[], char mot_code[], char *mode, int *score, long *curseur, Niveau *nbr_chance)
{
    char lettre = '0',
         conteneur = '0';
    int i = 0,
        indice = 0;

    printf("Quel est le mot secret ? %s\n", mot_code);
    printf("Proposez une lettre : ");

    lettre = read_Char();

    while(mot_secret[i] != '\0')
    {
        conteneur = mot_secret[i];

        if(conteneur == lettre)
        {
            mot_code[i] = lettre;
            indice = 1;
        }

        i++;
    }

    if(indice == 0)
    {
        (*nbr_chance)--;

        if(*nbr_chance != 0)
        {
            printf("\nRAT%c ! Il vous reste %d chance(s)\n\n", 144, *nbr_chance);
            (*score)++;
        }
        else
        {
            printf("\nDESOLE ! Vous n'avez plus de chance. Le mot secret %ctait %s.\nMerci de bien vouloir rejouer.\n\n", 130, mot_secret);
        }
    }
    else
    {
        if(strcmp(mot_secret, mot_code) != 0)
        {
            printf("\nBRAVO ! Vous avez toujours %d chance(s). ALLEZ CONTINUER !\n\n", *nbr_chance);
        }
        else
        {
            printf("\nFELICITATION ! Le mot secret etait belle et bien %s\n", mot_secret);
            if(*mode == 'A')
            {
                /*
                    Si c'est le mode A qui a �t� choisi, on entre dans le fichier qui contient la liste de joueur pour pouvoir modifier le score
                    du joueur. C'est pour quoi la fonction a pris en param�tre un pointeur sur le curseur virtuel.
                    A chaque jeu en mode A, le score sera modifier : ceci pour permettre au joueur d'avoir quelque fois la possibilit� de battre son record
                    car si jamais il fini le jeu avec 0 faute, il ne poura plus battre son record
                */
                FILE *fichier_texte = NULL;

                fichier_texte = fopen("DONNES JOUEURS/Solo/Joueur_unique.txt", "r+");

                if(fichier_texte != NULL)
                {
                    fseek(fichier_texte, *curseur, SEEK_SET);//On positionne le curseur virtuel net sur la ligne du score.

                    int ancien_score = 0;
                    fscanf(fichier_texte, "%d", &ancien_score);//On recup�re l'ancien score

                    rewind(fichier_texte);
                    fseek(fichier_texte, *curseur, SEEK_SET);
                    fprintf(fichier_texte, "%d\n\n", *score);

                    if(*score < ancien_score)
                    {
                        printf("BRAVO ! RECORE BATU : %d erreur(s). Ancien recore : %d erreur(s)\n\n", *score, ancien_score);
                    }
                    else
                    {
                        printf("%d erreur(s)\n\n", *score);
                    }

                    fclose(fichier_texte);
                }
                else
                {
                    printf("Erreur d'ouverture !\n\n");
                }
            }
            else
            {
                if(*score == 0)
                {
                    printf("INCROYABLE ! Vous avez retrouv%c le mot sans rater une seule lettre.\n\n", 130);
                }
                else
                {
                    printf("Nombre d'erreur : %d\n\n", *score);
                }
            }
        }
    }
}//FIN FONCTION DEROULEMENT DU JEU

//Cette fonction permet de choisir un nombre al�atoir dans un intervalle donn�. ici nombre_max
int nombreAleatoir(int nombre_max)
{
    srand(time(NULL));

    return (rand() % nombre_max);
}

//NIVEAU DE JEU : L'utilisateur doit choisir l'un des 3 niveaux de jeu propos�s.
int niveau_de_jeu()
{
    int niveau_choisi = 0;

    printf("---- NIVEAUX DISPONIBLES -----\n");
    printf("\t1- FACILE\n\t2- INTERMEDIAIRE\n\t3- DIFFICILE\n\n");

    printf("NIVEAU : ");
    scanf("%d", &niveau_choisi);
    getchar();

    while( niveau_choisi < 1 || niveau_choisi > 3 )
    {
        printf("Le niveau %d n'existe pas, veuillez r%cit%crer votre choix.\n", niveau_choisi, 130, 130);
        printf("NIVEAU : ");
        scanf("%d", &niveau_choisi);
        getchar();
    }

    return niveau_choisi;
}
